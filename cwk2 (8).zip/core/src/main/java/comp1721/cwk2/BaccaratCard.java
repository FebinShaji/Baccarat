// BaccaratCard.java created by: Febin Shaji

package comp1721.cwk2;

public class BaccaratCard extends Card  {

    // Declare Fields

    private Rank rank;
    private Suit suit;

    // Constructor to initialise the fields

    public BaccaratCard(Rank r, Suit s)  {
        super(r, s);
        this.rank = r;
        this.suit = s;
    }

    // Returns the rank of the card

    public Rank getRank()  {
        return rank;
    }

    // Returns the suit of the card

    public Suit getSuit()  {
        return suit;
    }

    // Returns formatted string containing the rank and suit of card

    public String toString()  {
        return String.format("%c%c", rank.getSymbol(), suit.getSymbol());
    }

    // Used to compare BaccaratCard objects

    @Override
    public boolean equals(Object other)  {
        if (other == this) {
            return true;
        }
        else if (other instanceof Card) {
            final BaccaratCard card = (BaccaratCard) other;
            return rank == card.rank && suit == card.suit;
        }
        return false;
    }

    // Used to compare BaccaratCard objects

    @Override
    public int compareTo(Card other)  {
        int difference = suit.compareTo(other.getSuit());
        if (difference == 0) {
          difference = rank.compareTo(other.getRank());
        }
        return difference;
    }

    // Returns the points value of the card

    public int value()  {
        int val;
        if (rank == Rank.ACE)  {
            return val = 1;
        }
        if (rank == Rank.TWO)  {
            return val = 2;
        }
        if (rank == Rank.THREE)  {
            return val = 3;
        }
        if (rank == Rank.FOUR)  {
            return val = 4;
        }
        if (rank == Rank.FIVE)  {
            return val = 5;
        }
        if (rank == Rank.SIX)  {
            return val = 6;
        }
        if (rank == Rank.SEVEN)  {
            return val = 7;
        }
        if (rank == Rank.EIGHT)  {
            return val = 8;
        }
        if (rank == Rank.NINE)  {
            return val = 9;
        }
        else {
            return val = 0;
        }
    }
}
