// BaccaratHand.java created by: Febin Shaji

package comp1721.cwk2;

import java.util.*;

public class BaccaratHand extends CardCollection  {

    // Declare Fields

    protected List<Card> cards;

    // Constructor to initialise the fields

    public BaccaratHand()  {
        cards = new LinkedList<>();
    }

    // Returns the number of cards in hand

    public int size()  {
        return cards.size();
    }

    // Adds a card to the list of cards

    public void add(Card card)  {
        cards.add(card);
    }

    // Returns the points value of a hand

    public int value()  {
        int sum = 0;
        for (Card card: cards) {
            sum += card.value();
        }
        if (sum > 9)    {
            sum = sum % (int) Math.pow(10, (int) Math.log10(sum));
        }
        return sum;
    }

    // Returns boolean value depending on whether the points value of the hand is 8, 9 or not

    public boolean isNatural()  {
        int val;
        val = value();
        if(val == 8 || val == 9)    {
            return true;
        }
        return false;
    }

    // Returns formatted string for the cards in the hand

    public String toString()  {
        int i = 0;
        while (i < cards.size()) {
            if (cards.size() == 1)  {
                return String.format("%s", cards.get(i));
            }
            if (cards.size() == 2)  {
                return String.format("%s %s", cards.get(i), cards.get(i + 1));
            }
            if (cards.size() == 3)  {
                return String.format("%s %s %s", cards.get(i), cards.get(i + 1), cards.get(i + 2));
            }
        }
        return "";
    }
}
