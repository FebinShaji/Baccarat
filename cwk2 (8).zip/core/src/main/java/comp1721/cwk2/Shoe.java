// Shoe.java created by: Febin Shaji

package comp1721.cwk2;

import java.util.*;

public class Shoe extends CardCollection  {

    // Checks if decks is not 6 or 8 and if not then throws a CardException
    // If it is 6 or 8 then adds all the cards to the list

    public Shoe(int decks)  {
        if (decks != 6 && decks != 8)   {
            throw new CardException("Wrong value for number of decks");
        }
        else    {
            Card.Suit arr1[] = Card.Suit.values();
            Card.Rank arr2[] = Card.Rank.values();
            for (int i = 0; i < decks; i++) {
                for (Card.Suit Suits: arr1)  {
                    for (Card.Rank Ranks: arr2)  {
                        BaccaratCard a = new BaccaratCard(Ranks, Suits);
                        add(a);
                    }
                }
            }
        }
    }

    // Returns the number of cards

    public int size()  {
        return cards.size();
    }

    // Shuffles the cards

    public void shuffle()  {
        Collections.shuffle(cards);
    }

    // Checks if cards is empty and if it is throws a CardException
    // Removes the first card and returns it

    public Card deal()  {
        if (cards.isEmpty())   {
            throw new CardException("Shoe is empty"); 
        }
        return cards.remove(0);
    }
}
