package comp1721.cwk2;

public class Baccarat {
  // Implement your Intermediate or Full solution in this class
}
